package com.nokia.cap.nokiacaplibrary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NokiaCapModule extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nokia_cap_module);
    }
}
