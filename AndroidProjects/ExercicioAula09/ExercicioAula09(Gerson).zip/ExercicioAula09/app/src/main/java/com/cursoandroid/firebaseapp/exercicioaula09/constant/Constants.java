package com.cursoandroid.firebaseapp.exercicioaula09.constant;

/**
 * Created by gersonsales at Embedded Enterprise on 06/01/18.
 */

public class Constants {
    public static final String RESULT = "Result";
    public static final String CANCELED = "Canceled";
}
