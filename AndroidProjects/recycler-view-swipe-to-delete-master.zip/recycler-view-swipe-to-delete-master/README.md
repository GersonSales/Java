# recycler-view-swipe-to-delete
Sample project showing "swipe to delete" on a recycler view with no 3rd parties involved. It also include drawing on empty space while items are animating and an "undo" option

Blog post with gif animations of the sample app:
http://nemanjakovacevic.net/blog/english/2016/01/12/recyclerview-swipe-to-delete-no-3rd-party-lib-necessary/
